# -*- coding: utf-8 -*-

# Copyright (c) 2016 - 2020 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Package implementing a hex editor.
"""

#
# This is a Python only variant of QHexEdit2 created by Winfried Simon.
# Winfried Simon <winfried.simon@gmail.com>
#
